from tkinter import *
#from ucasts import ID12LA
import tkinter as tk
import threading
#import RPi.GPIO as GPIO
from threading import Timer
 
class App(threading.Thread):
       
    def __init__(self):
        threading.Thread.__init__(self)   #initiates a general program known as Self running in Background
        
        
        #Main Window
        self.start()
        self.root = tk.Tk()
        self.root.wm_title("Republic Poly Direction Kiosk")
        self.root.protocol("WM_DELETE_WINDOW", self.callback)
        #self.root.state('-zoomed', True) #use this to have FULLSCREEN instead of maximized screen
        self.root.wm_state('zoomed') #contains a main window in maximized screen mode that comprises left and right frames
        #Variables
        #self.RFID = StringVar()
        RFID = StringVar()
        RFID.set('-==Awaiting Scan==-')
        self.Clinic = PhotoImage()
        t= None
        def reset(): #this was meant to auto restart program after a while
                print("Resetting")
                RFID.set('-==Awaiting Scan==-')
                self.Clinic=PhotoImage(file='Clinic.gif')
                Label(self.root, image=self.Clinic).grid(row=1, column=3)
                
                t.cancel()
                

        def validate(event):
           global t
           t=Timer(2,reset) #timer to reset everything
           
           if RFID.get() == "1111": #try keying 1111 in at 'Awaiting Scan box' and press enter then wait a while
                print("ClinicA")
                self.Clinic=PhotoImage(file='ClinicA.gif')
                Label(self.root, image=self.Clinic).grid(row=1, column=3)
                
                t.start()
                
           elif RFID.get()=="2222":
                print("Clinic B")
                self.Clinic=PhotoImage(file='ClinicB.gif')
                Label(self.root, image=self.Clinic).grid(row=1, column=3)
                t.start()
                
           elif RFID.get()=="3333":
                print("Clinic B")
                self.Clinic=PhotoImage(file='ClinicC.gif')
                Label(self.root, image=self.Clinic).grid(row=1, column=3)
                t.start()
           else:
               print("error")
               self.Clinic=PhotoImage(file='RPlogo.gif')
               Label(self.root, image=self.Clinic).grid(row=1, column=3)
               t.start()
            
        #LeftFrame for RP logo
        leftFrame = Frame(self.root, width=5, height =5, bd=5,relief=SUNKEN)
        leftFrame.grid(row=0, column=3)
        Label(leftFrame, text = "Welcome to RP Direction Kiosk", font=("Arial", 18)).grid(row=0, column=2,)
        self.imageRP = PhotoImage(file='RPlogo.gif')
        Label(leftFrame, image=self.imageRP).grid(row=1, column=2)
        Label(leftFrame, text = "Please Scan Tag", font =("Arial", 15)).grid(row=2, column=2)
        RFID_entry = Entry(leftFrame, textvariable = RFID, width=20)
        RFID_entry.grid(row=3,column=2)
        RFID_entry.bind('<Return>',validate)
        Button(leftFrame, text="Card 1", command = self.card1).grid(row=4, column=1)
        Button(leftFrame, text="Card 2", command = self.card2).grid(row=4, column=2)
        Button(leftFrame, text="Card 3", command = self.card3).grid(row=4, column=3)
        
        #RightFrame for Map/Route
        rightFrame = Frame(self.root, width=500, height =480, bd=2, relief=SUNKEN)
        rightFrame.grid(row=1, column=3)
        #Label(rightFrame, text = "test").grid(row=0, column=3)
        self.Clinic = PhotoImage(file='Clinic.gif')
        Label(self.root, image=self.Clinic).grid(row=1, column=3)  
        self.root.mainloop()
        
        
    
    def card1(self):
       self.Clinic= PhotoImage(file='ClinicA.gif')
       Label(self.root, image=self.Clinic).grid(row=1, column=3)
    def card2(self):
       self.Clinic= PhotoImage(file='ClinicB.gif')
       Label(self.root, image=self.Clinic).grid(row=1, column=3)
    def card3(self):
       self.Clinic= PhotoImage(file='ClinicC.gif')
       Label(self.root, image=self.Clinic).grid(row=1, column=3)
    def callback(self): #does a proper 'self' program closure when called
        self.root.quit()

    def run(self): #additional program to run during the application of 'self'
        reader = ID12LA()
        #def scan():
            #while True:
                
                #tag = reader.wait_for_scan() #reads the rfid scaner
                #print ("Scanned %s") % (tag,)
                #self.RFID.set(tag) #sets the textbox the read ID
                                
                #each card will show different 'route'
                #if tag=="1234":
                    #print("Clinic A")
                    #self.Clinic=PhotoImage(file='ClinicA.gif')
                    #Label(self.root, image=self.Clinic).grid(row=0, column=1)
                    
                #elif tag=="4321":
                    #print("Clinic B")
                    #self.Clinic=PhotoImage(file='ClinicB.gif')
                    #Label(self.root, image=self.Clinic).grid(row=0, column=1)
                    
                #else:
                    #print("error")
                    #self.Clinic=PhotoImage(file='RPlogo.gif')
                    #Label(self.root, image=self.Clinic).grid(row=0, column=1)
        #scan()
app = App()

    

